"""
Helper functions for image processing and UI
"""

import numpy as np
from pathlib import Path


def clamp(value: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """
    Clamp a value between min and max.
    
    Args:
        value: Value to clamp
        min_val: Minimum value
        max_val: Maximum value
        
    Returns:
        float: Clamped value
    """
    return max(min_val, min(max_val, value))


def ensure_rgb(image: np.ndarray) -> np.ndarray:
    """
    Ensure image is in RGB format.
    
    Args:
        image: Image array
        
    Returns:
        np.ndarray: RGB image
    """
    if len(image.shape) == 2:
        # Grayscale to RGB
        return np.stack([image, image, image], axis=2)
    elif image.shape[2] == 4:
        # RGBA to RGB (drop alpha)
        return image[:, :, :3]
    elif image.shape[2] == 3:
        return image
    else:
        raise ValueError(f"Unsupported image shape: {image.shape}")


def get_resource_path(resource_name: str) -> Path:
    """
    Get path to a resource file.
    
    Args:
        resource_name: Name of resource (relative path in resources/)
        
    Returns:
        Path: Full path to resource
    """
    app_dir = Path(__file__).parent.parent
    resource_path = app_dir / "resources" / resource_name
    return resource_path
