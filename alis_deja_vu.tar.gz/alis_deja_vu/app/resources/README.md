# Resources

This directory contains application assets including icons and images.

## Contents

### app_icon.png
The main application icon (256x256 pixels)
- Used in title bar
- Used in taskbar
- Used in About dialog
- Format: PNG with transparency

### app_icon.ico
Windows icon file (256x256 pixels)
- Used in Windows executable
- Created automatically during build
- Required for PyInstaller

## Creating Icons

To create application icons:

1. **Design icon as PNG** (256x256 pixels minimum)
   - Keep it minimal and elegant
   - Use photography/editorial aesthetic
   - Dark theme compatible

2. **Save as PNG**:
   - Location: `app/resources/app_icon.png`
   - Size: 256x256 pixels
   - Format: PNG with alpha channel

3. **Convert to ICO** (for Windows):
   ```bash
   # Using PIL
   from PIL import Image
   img = Image.open('app_icon.png')
   img.save('app_icon.ico')
   ```

   Or use an online converter:
   - https://icoconvert.com/
   - https://convertio.co/png-ico/

4. **Update in build_exe.bat**:
   The script already references `app/resources/app_icon.ico`

## Icon Guidelines

- **Style**: Modern, minimal, professional
- **Theme**: Photography/editorial aesthetic
- **Color**: Should work on dark backgrounds
- **Simplicity**: Recognizable at small sizes (16x16)
- **Uniqueness**: Distinct from generic camera/photo icons

## Placeholder

Currently, the application runs without custom icons using Qt's default icons.

To enable custom icons:
1. Create or find appropriate icon PNG (256x256)
2. Save as `app_icon.png` in this directory
3. Convert to `app_icon.ico` for Windows
4. Run build process normally
