"""
Resources - Application icons and assets
"""

# This directory contains application resources such as:
# - app_icon.png - Application icon
# - app_icon.ico - Windows icon for executable
