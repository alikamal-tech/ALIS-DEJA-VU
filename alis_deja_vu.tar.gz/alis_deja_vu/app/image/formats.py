"""
Image formats - Supported file types and their properties
"""

# Standard image formats (always supported via Pillow)
STANDARD_FORMATS = {
    '.jpg': 'JPEG Image',
    '.jpeg': 'JPEG Image',
    '.png': 'PNG Image',
    '.tiff': 'TIFF Image',
    '.tif': 'TIFF Image',
}

# RAW formats (supported via rawpy when available)
RAW_FORMATS = {
    '.cr2': 'Canon RAW 2',
    '.cr3': 'Canon RAW 3',
    '.nef': 'Nikon RAW',
    '.arw': 'Sony RAW',
    '.dng': 'Digital Negative',
    '.raf': 'Fujifilm RAW',
    '.orf': 'Olympus RAW',
    '.rw2': 'Panasonic RAW',
}

# All supported formats
SUPPORTED_FORMATS = {**STANDARD_FORMATS, **RAW_FORMATS}

# File filter string for dialogs
SUPPORTED_FORMATS_FILTER = (
    "All Supported Images (*.jpg *.jpeg *.png *.tiff *.tif *.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2);;"
    "JPEG Images (*.jpg *.jpeg);;"
    "PNG Images (*.png);;"
    "TIFF Images (*.tiff *.tif);;"
    "RAW Images (*.cr2 *.cr3 *.nef *.arw *.dng *.raf *.orf *.rw2);;"
    "All Files (*.*)"
)

# Export formats
EXPORT_FORMATS = {
    '.jpg': 'JPEG',
    '.jpeg': 'JPEG',
    '.png': 'PNG',
    '.tiff': 'TIFF',
    '.tif': 'TIFF',
}

EXPORT_FORMATS_FILTER = (
    "JPEG Images (*.jpg *.jpeg);;"
    "PNG Images (*.png);;"
    "TIFF Images (*.tiff *.tif)"
)
