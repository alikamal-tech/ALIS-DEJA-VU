"""
Core module - Image data structures and undo/redo system
"""

from app.core.image import ImageData
from app.core.undo_redo import UndoRedoManager

__all__ = ['ImageData', 'UndoRedoManager']
