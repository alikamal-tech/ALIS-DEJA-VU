# ALIS DEJA VU - Quick Start Guide

## What You Just Downloaded

A complete, professional-grade photo editing application for Windows built in Python.

**Version**: 0.1.0 (Phase 1 - Foundation)

---

## Installation (2 Minutes)

### 1. Prerequisites
- **Windows 10 or 11**
- **Python 3.9+** from https://www.python.org/downloads/
  - ⚠️ Check "Add Python to PATH" during installation

### 2. Install Dependencies
Open Command Prompt in the project folder and run:

```bash
py -m pip install -r requirements.txt
```

This installs all required libraries (takes 2-5 minutes on first run).

---

## Running the Application

### Option 1: Double-Click (Easiest)
Just double-click **`run.bat`** in the project folder.

### Option 2: Command Prompt
```bash
run.bat
```

### Option 3: Manual Python
```bash
py -m app.main
```

---

## First Steps

1. **Open an Image**: File → Open Image (or Ctrl+O)
2. **Adjust**: Use sliders on the right side
3. **Zoom**: Use mouse wheel or 0/1 keys
4. **Pan**: Middle mouse button + drag
5. **Export**: File → Export As (or Ctrl+Shift+S)
6. **Undo**: Ctrl+Z

---

## Project Structure

```
alis_deja_vu/
├── run.bat                  ← Start here!
├── build_exe.bat            ← Create Windows .exe
├── requirements.txt         ← Python dependencies
├── README.md                ← Full documentation
│
├── app/                     ← Main application
│   ├── main.py              ← Entry point
│   ├── core/                ← Image data & undo/redo
│   ├── image/               ← Load/save images
│   ├── processing/          ← Image algorithms
│   ├── ui/                  ← User interface
│   ├── resources/           ← Icons (placeholder)
│   └── utils/               ← Helper functions
│
├── tests/                   ← Unit tests
├── docs/                    ← Documentation
│   ├── ARCHITECTURE.md      ← System design
│   ├── LICENSES.md          ← Open-source licenses
│   └── FEATURE_RESEARCH.md  ← Photo editing research
│
└── QUICKSTART.md            ← This file!
```

---

## Current Features (Phase 1)

✅ **Image Viewer**
- Load JPEG, PNG, TIFF, RAW
- Zoom with mouse wheel
- Pan with middle mouse button
- Fit-to-window and actual-size views

✅ **Basic Adjustments**
- Exposure (brighten/darken)
- Brightness (lift/crush)
- Contrast (separation)
- Saturation (color intensity)
- Temperature (warm/cool tones)

✅ **Professional Workflow**
- Real-time preview
- Full undo/redo (up to 50 steps)
- Non-destructive editing
- Export to JPEG/PNG/TIFF

✅ **Dark Professional Interface**
- Clean, modern design
- Optimized for creative work
- Keyboard shortcuts
- Responsive controls

---

## Upcoming Features

### Phase 2 (Next)
- [ ] Layers with masks
- [ ] Advanced color curves
- [ ] Histogram display

### Phase 3 (After)
- [ ] Retouching tools (heal, clone)
- [ ] Frequency separation
- [ ] Dodge & burn

### Phase 4+
- [ ] Portrait enhancement presets
- [ ] Skin retouching tools
- [ ] Project system
- [ ] Batch processing

---

## Common Tasks

### Open Image
- **Menu**: File > Open Image
- **Shortcut**: Ctrl+O
- **Drag & Drop**: Drag image into window (future)

### Export Photo
- **Menu**: File > Export As
- **Shortcut**: Ctrl+Shift+S
- **Formats**: JPEG (with quality), PNG, TIFF

### Undo Last Change
- **Shortcut**: Ctrl+Z
- **Keyboard**: Type "Z" while holding Ctrl
- **Menu**: Edit > Undo

### Zoom
- **Mouse**: Scroll wheel
- **Keyboard**: + or - keys
- **Fit Window**: Press 0
- **Actual Size**: Press 1

### Reset Image
- **Menu**: Edit > Reset Image
- Clears all adjustments, returns to original

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+O | Open Image |
| Ctrl+Shift+S | Export As |
| Ctrl+Z | Undo |
| Ctrl+Y | Redo |
| Ctrl++ | Zoom In |
| Ctrl+- | Zoom Out |
| 0 | Fit to Window |
| 1 | 100% Actual Size |
| Alt+F4 | Exit |

---

## Building an Executable

To create a standalone Windows .exe:

```bash
build_exe.bat
```

This creates `dist/ALIS DEJA VU.exe` that runs without Python!

(Requires PyInstaller, installed automatically)

---

## Troubleshooting

### "Python is not installed"
- Download from https://www.python.org/downloads/
- Make sure to check "Add Python to PATH"
- Restart Command Prompt after installing

### "ModuleNotFoundError"
```bash
# Reinstall dependencies
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

### "Can't open image"
- Ensure file is: JPEG, PNG, TIFF, or RAW
- Check file isn't corrupted
- Try converting to JPEG first

### Application is slow
- Reduce image size
- Check your system has 4GB+ RAM
- Close other applications

### RAW images don't open
- RAW support requires `rawpy` package
- Usually installs automatically
- If not: `py -m pip install rawpy`

---

## Architecture Overview

The app is organized in clean layers:

```
UI Layer (PySide6/Qt)
    ↓
Processing Layer (NumPy/OpenCV algorithms)
    ↓
Data Layer (Image data structures)
    ↓
File I/O (Load/save operations)
```

This means:
- **Easy to test** - Processing works independently
- **Easy to extend** - Add features without touching existing code
- **Easy to maintain** - Clear separation of concerns

---

## Development

### Running Tests
```bash
py -m pytest tests/
```

### Adding New Features
1. Create algorithm in `app/processing/`
2. Add UI control in `app/ui/main_window.py`
3. Connect signal/slot
4. Add test in `tests/`
5. Update documentation

---

## Important Notes

### Offline & Private
✅ Completely offline - no internet required
✅ No cloud uploads - images stay on your computer
✅ No tracking - completely private
✅ No AI - all local classical algorithms
✅ Free & open-source - no subscriptions

### Non-Destructive
- Original image always preserved
- All edits are reversible
- Can undo any change
- Adjustments stored as parameters

### Windows-First
- Optimized for Windows 10/11
- Uses Python Launcher (py -m)
- Supports Unicode/Arabic paths
- Professional Windows .exe building

---

## Getting Help

### Documentation
- **README.md** - Full feature documentation
- **docs/ARCHITECTURE.md** - How it's built
- **docs/LICENSES.md** - Open-source licenses
- **docs/FEATURE_RESEARCH.md** - Photography research

### Troubleshooting
1. Check the Troubleshooting section above
2. Review README.md FAQ
3. Check docs/ARCHITECTURE.md for technical info

---

## Next Steps

1. **Run the app**: Double-click `run.bat`
2. **Open a photo**: File > Open Image
3. **Try adjustments**: Move the sliders
4. **Export**: File > Export As
5. **Read full docs**: Open `README.md`

---

## Architecture Quick Ref

| Folder | Purpose |
|--------|---------|
| `app/core/` | Image data & undo/redo |
| `app/image/` | Load/save images |
| `app/processing/` | Adjustment algorithms |
| `app/ui/` | User interface |
| `app/utils/` | Helper functions |
| `tests/` | Unit tests |
| `docs/` | Documentation |

---

## Credits & Thanks

Built with:
- **PySide6** - Qt for Python (LGPL)
- **NumPy** - Numerical computing (BSD)
- **Pillow** - Image I/O (HPND)
- **OpenCV** - Computer vision (Apache 2.0)
- **scikit-image** - Image algorithms (BSD)

Inspired by:
- **GIMP** - Layer system design
- **Darktable** - Professional workflow
- **RawTherapee** - Color science
- **Krita** - Interface design

---

## Version Info

- **App**: ALIS DEJA VU v0.1.0
- **Release Date**: 2024
- **Status**: Foundation/Beta
- **Platform**: Windows 10/11
- **Python**: 3.9+

---

## License

Open-source project using MIT or BSD licenses.

See `docs/LICENSES.md` for complete license information.

---

**Welcome to ALIS DEJA VU!**

*Professional Portrait & Fashion Photo Editing*
*Dark. Elegant. Offline.*

💡 **Tip**: Start with the README.md for comprehensive documentation.
