# Third-Party Licenses

ALIS DEJA VU is built using high-quality open-source libraries. This document lists all third-party dependencies and their licenses.

---

## Direct Dependencies

### GUI Framework

#### PySide6
- **Version**: 6.4.0+
- **License**: LGPL (Lesser GNU Public License)
- **Source**: https://wiki.qt.io/Qt_for_Python
- **Purpose**: Qt6 Python bindings for GUI
- **License Text**: https://www.gnu.org/licenses/lgpl-3.0.en.html

### Numerical Computing

#### NumPy
- **Version**: 1.23.0+
- **License**: BSD
- **Source**: https://numpy.org/
- **Purpose**: Numerical array processing and vectorization
- **License Text**: https://github.com/numpy/numpy/blob/main/LICENSE.txt

### Image Processing

#### Pillow (PIL)
- **Version**: 9.5.0+
- **License**: HPND (Historical Permission Notice and Disclaimer)
- **Source**: https://python-pillow.org/
- **Purpose**: Image loading, saving, and basic processing
- **License Text**: https://github.com/python-pillow/Pillow/blob/main/LICENSE

#### OpenCV (opencv-python)
- **Version**: 4.7.0+
- **License**: Apache 2.0
- **Source**: https://opencv.org/
- **Purpose**: Advanced image processing and computer vision
- **License Text**: https://github.com/opencv/opencv/blob/master/LICENSE

#### scikit-image
- **Version**: 0.20.0+
- **License**: BSD (3-clause)
- **Source**: https://scikit-image.org/
- **Purpose**: Advanced image processing algorithms
- **License Text**: https://github.com/scikit-image/scikit-image/blob/main/LICENSE.txt

#### SciPy
- **Version**: 1.x (implicit dependency of scikit-image)
- **License**: BSD
- **Source**: https://scipy.org/
- **Purpose**: Scientific computing functions
- **License Text**: https://github.com/scipy/scipy/blob/main/LICENSE.txt

### RAW Image Support

#### rawpy
- **Version**: 0.18.0+
- **License**: MIT
- **Source**: https://github.com/letmaik/rawpy
- **Purpose**: Read RAW image files from digital cameras
- **License Text**: https://github.com/letmaik/rawpy/blob/master/LICENSE

#### LibRaw (C dependency of rawpy)
- **Version**: Latest (via rawpy)
- **License**: LGPL / Commercial
- **Source**: https://www.libraw.org/
- **Purpose**: RAW file decoding
- **Note**: rawpy handles licensing - we use it as a library

### Image I/O

#### imageio
- **Version**: 2.25.0+
- **License**: BSD
- **Source**: https://imageio.readthedocs.io/
- **Purpose**: Image I/O utilities
- **License Text**: https://github.com/imageio/imageio/blob/master/LICENSE

---

## Implicit Dependencies

These are dependencies of our dependencies (installed automatically):

### Core Libraries
- **python-dateutil** (BSD) - Date/time utilities
- **pytz** (MIT) - Timezone database
- **kiwisolver** (BSD) - Constraint solving
- **packaging** (MIT or Apache 2.0) - Package utilities

### Image Libraries
- **Pillow-SIMD** (optional, HPND) - SIMD-accelerated Pillow
- **libjpeg** (IJG license) - JPEG encoding/decoding
- **libpng** (PNG Group license) - PNG encoding/decoding
- **libtiff** (BSD-like) - TIFF encoding/decoding
- **libwebp** (BSD) - WebP encoding/decoding

### Numerical Computing
- **BLAS/LAPACK** (BSD) - Linear algebra libraries
- **FFTPACK** (BSD) - FFT implementation

---

## Development Dependencies (Optional)

These are only needed for development, not for running the application:

### Testing

#### pytest
- **License**: MIT
- **Purpose**: Unit testing framework

### Building

#### PyInstaller
- **License**: GPL-2.0-or-later + exceptions
- **Purpose**: Create Windows executables
- **Note**: Only used during build process, not included in executable

#### setuptools
- **License**: MIT
- **Purpose**: Package distribution utilities

---

## License Compatibility

### Summary
- ✅ **LGPL** (PySide6) - Allows proprietary use with shared library linking
- ✅ **BSD** (NumPy, scipy, scikit-image, etc.) - Permissive, minimal requirements
- ✅ **MIT** (rawpy, pytest, setuptools) - Very permissive
- ✅ **Apache 2.0** (OpenCV, PyInstaller) - Permissive with patent clause
- ✅ **HPND** (Pillow) - Permissive
- ✅ **IJG** (libjpeg) - Permissive for non-commercial use

### Application License
ALIS DEJA VU is built to be compatible with all these licenses. The application can be distributed under:
- **MIT License** (Recommended)
- **BSD 3-Clause License** (Also compatible)
- **GPL 3.0** (If needed, due to LGPL compatibility)

---

## Third-Party Attribution

When distributing ALIS DEJA VU, include this attribution:

```
ALIS DEJA VU uses the following open-source libraries:

- PySide6 (LGPL)
- NumPy (BSD)
- Pillow (HPND)
- OpenCV (Apache 2.0)
- scikit-image (BSD)
- rawpy (MIT)
- imageio (BSD)
- SciPy (BSD)

For detailed license information, see:
docs/LICENSES.md
```

---

## License Compliance

### For End Users
- ✅ Use ALIS DEJA VU for personal and commercial purposes
- ✅ Modify source code for your needs
- ✅ Distribute modified versions
- ⚠️ Must include license notices (as above)

### For Developers
- ✅ Use as a base for proprietary applications (due to LGPL exceptions)
- ✅ Modify and redistribute
- ⚠️ Must provide source code access to modified LGPL components
- ⚠️ Follow individual library license requirements

### Build & Distribution
- PyInstaller (GPLv2) is used only for building, not included in final executable
- The executable itself is not subject to GPLv2
- Source code remains distributable under your chosen license

---

## Checking Licenses Yourself

To verify licenses of installed packages:

```bash
# List all packages and licenses
pip list

# For detailed info on specific package
pip show package_name

# Check raw license file
python -c "import package_name; print(package_name.__file__)"
```

To verify licenses in this project:

```bash
# View requirements
cat requirements.txt

# Check PyPI for each package
# https://pypi.org/project/package_name/
```

---

## Proprietary Code

ALIS DEJA VU's proprietary code (all `.py` files in `app/`) is licensed separately. By default:

- **License**: MIT License
- **Copyright**: 2024 ALIS DEJA VU Development
- **Restrictions**: None (subject to original licenses of dependencies)

You are free to:
- ✅ Use commercially
- ✅ Modify
- ✅ Distribute
- ✅ Use privately
- ✅ Sublicense (as long as you include the original license)

---

## Important Notes

### LGPL & Closed Source
PySide6 uses LGPL, which means:
- You can use it in closed-source applications
- You must provide a way for users to swap out the Qt library
- If you modify Qt/PySide6 itself, you must provide those modifications

We recommend keeping ALIS DEJA VU open-source to avoid compliance complexity.

### GPU Libraries (Future)
If future versions add GPU acceleration (CUDA, OpenCL):
- NVIDIA CUDA Toolkit: **NVIDIA license** (check their EULA)
- OpenCL: **Various** (dependent on implementation)

These would be optional, not required.

### AI Models (Future)
If future versions add local AI models:
- Model licenses vary by source
- Each model will require individual license review
- Will be documented separately

---

## Updates

This document is current as of version 0.1.0. When updating dependencies:

1. Check PyPI for license information
2. Review the license file in the package
3. Update this document
4. Verify license compatibility

---

## Questions?

For license questions:
- Check [opensource.org](https://opensource.org/licenses/) for license details
- Visit individual project websites (links above)
- Consult with legal counsel for specific use cases

---

## Summary Table

| Package | Version | License | Usage |
|---------|---------|---------|-------|
| PySide6 | 6.4.0+ | LGPL 3.0 | GUI Framework |
| NumPy | 1.23.0+ | BSD | Numerical Computing |
| Pillow | 9.5.0+ | HPND | Image I/O |
| OpenCV | 4.7.0+ | Apache 2.0 | Image Processing |
| scikit-image | 0.20.0+ | BSD | Image Algorithms |
| rawpy | 0.18.0+ | MIT | RAW Files |
| imageio | 2.25.0+ | BSD | Image I/O Utils |
| SciPy | 1.x | BSD | Scientific Ops |

---

**Last Updated**: Version 0.1.0
**Next Review**: When dependencies are updated
