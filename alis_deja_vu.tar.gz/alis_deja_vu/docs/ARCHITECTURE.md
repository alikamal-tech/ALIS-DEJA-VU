# ALIS DEJA VU - Architecture

## System Design

ALIS DEJA VU follows a **clean architecture** principle separating concerns into distinct layers:

```
┌─────────────────────────────────────────┐
│          UI Layer (PySide6/Qt)          │
│  ┌───────────────────────────────────┐  │
│  │  MainWindow, Widgets, Dialogs     │  │
│  │  Theme, Styling                   │  │
│  └───────────────────────────────────┘  │
└─────────────────────────────────────────┘
           ↓              ↓
┌──────────────────────────────────────────┐
│      Application Logic / Services        │
│  ┌────────────────────────────────────┐  │
│  │  Image Loading/Saving              │  │
│  │  Undo/Redo Management              │  │
│  │  Project Management                │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
           ↓              ↓
┌──────────────────────────────────────────┐
│      Processing Layer (Algorithms)       │
│  ┌────────────────────────────────────┐  │
│  │  Image Adjustments                 │  │
│  │  Color Transforms                  │  │
│  │  Retouching Algorithms             │  │
│  │  Filter Operations                 │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
           ↓              ↓
┌──────────────────────────────────────────┐
│      Data Layer (Image Data)             │
│  ┌────────────────────────────────────┐  │
│  │  ImageData (numpy arrays)          │  │
│  │  Layer Stack                       │  │
│  │  Adjustment State                  │  │
│  └────────────────────────────────────┘  │
└──────────────────────────────────────────┘
```

### Key Principles

1. **Separation of Concerns**: UI, Processing, and Data are independent
2. **Testability**: Processing algorithms work without GUI
3. **Maintainability**: Clear module boundaries and responsibilities
4. **Extensibility**: New features can be added without modifying existing code
5. **Performance**: Algorithms optimized with NumPy vectorization

---

## Module Overview

### 1. Core (`app/core/`)

**Purpose**: Core data structures and undo/redo system

#### `image.py` - ImageData Class
- Represents an image with non-destructive editing capabilities
- Stores:
  - Original image (never modified)
  - Working image (current state)
  - Adjustment parameters
  - Layer information (future)
- Key Methods:
  - `get_working_image()` - Current image data
  - `update_working_image()` - Update working state
  - `reset_to_original()` - Clear all changes
  - `set_adjustment()` / `get_adjustment()` - Parameter storage

#### `undo_redo.py` - Undo/Redo System
- Implements Command Pattern for reversible operations
- Classes:
  - `EditCommand` - Base class for all reversible operations
  - `ImageAdjustmentCommand` - Specific to image adjustments
  - `UndoRedoManager` - Manages history and navigation
- Features:
  - Full undo/redo history
  - Memory-efficient (limited history size)
  - Can query available operations

---

### 2. Image (`app/image/`)

**Purpose**: Image file I/O and format handling

#### `formats.py` - Format Definitions
- Defines supported image formats
- Separates standard formats (JPEG, PNG, TIFF) from RAW formats
- Provides file filter strings for dialogs

#### `loader.py` - ImageLoader Class
- Loads images from disk
- Features:
  - Automatic format detection
  - RAW support via rawpy (optional)
  - Graceful fallback for unsupported formats
  - Image normalization (0-1 float range)
- Methods:
  - `load()` - Load image from file
  - `can_load()` - Check if format is supported
  - `get_supported_extensions()` - List available formats

#### `saver.py` - ImageSaver Class
- Saves/exports images to disk
- Features:
  - Multiple output formats
  - Quality control (JPEG)
  - Automatic format conversion
- Methods:
  - `save()` - Save image to file with options
  - `_array_to_pil()` - Convert numpy to PIL image

---

### 3. Processing (`app/processing/`)

**Purpose**: Image adjustment and processing algorithms

#### `adjustments.py` - Core Algorithms
Pure functions implementing image processing:

**Basic Adjustments:**
- `adjust_exposure(image, exposure)` - Multiplicative brightness
- `adjust_brightness(image, brightness)` - Additive brightness
- `adjust_contrast(image, contrast)` - Contrast via pivoting

**Color Adjustments:**
- `adjust_saturation(image, saturation)` - RGB saturation
- `adjust_temperature(image, temperature)` - Warm/cool tones
- `adjust_highlights_shadows(image, highlights, shadows)` - Tonal adjustments

**Advanced (Planned):**
- `apply_curve(image, curve_points)` - Tone curves
- `adjust_hsv()` - HSL adjustments
- `frequency_separation()` - Frequency separation
- `healing_brush()` - Retouching

**Design**: All functions:
- Accept 0-1 float normalized images
- Return 0-1 float normalized images
- Are stateless (pure functions)
- Use NumPy vectorization
- Can be tested independently

---

### 4. UI (`app/ui/`)

**Purpose**: User interface and interaction

#### `theme.py` - Theming System
- `Colors` - Dark professional color palette
- `Fonts` - Typography definitions
- `StyleSheet` - Qt stylesheet generation
- Feature: Single source of truth for colors

#### `widgets.py` - Custom Qt Widgets

**ImageCanvas**:
- Professional image viewer
- Features:
  - Smooth zoom with mouse wheel
  - Pan with middle mouse button
  - Fit-to-window, actual-size modes
  - Real-time zoom indicator
  - Before/after comparison (future)

**ControlPanel**:
- Reusable panel for grouped controls
- Built-in slider + label + value display
- Consistent styling

#### `main_window.py` - Main Application Window

**Architecture**:
```
MainWindow
├── MenuBar
│   ├── File (Open, Export, Exit)
│   ├── Edit (Undo, Redo, Reset)
│   └── View (Zoom controls)
│
├── Workspace
│   ├── LeftPanel (Tools)
│   ├── ImageCanvas (Center, resizable)
│   └── RightPanel (Adjustments)
│
└── StatusBar (Zoom %, Image info)
```

**Key Responsibilities**:
- Coordinate between UI and processing
- Handle file I/O
- Manage undo/redo
- Update canvas on changes
- Synchronize adjustment sliders

---

### 5. Utils (`app/utils/`)

**Purpose**: Helper functions and utilities

#### `helpers.py`
- `clamp()` - Constrain values within range
- `ensure_rgb()` - Normalize image to RGB
- `get_resource_path()` - Locate resource files

---

## Data Flow

### Opening an Image

```
User clicks "Open Image"
    ↓
FileDialog.getOpenFileName()
    ↓
MainWindow.load_image(path)
    ↓
ImageLoader.can_load(path)?
    ↓
ImageData = ImageData(path)
    ↓
ImageLoader.load(path) → numpy array
    ↓
ImageData stores original + working image
    ↓
Canvas.set_image(working_image)
    ↓
Canvas.paintEvent() renders to screen
```

### Adjusting an Image

```
User moves Exposure slider
    ↓
MainWindow._on_exposure_changed(value)
    ↓
adjust_exposure(original_image, value)
    ↓
ImageData.update_working_image(result)
    ↓
ImageData stores adjustment parameter
    ↓
Canvas.set_image(working_image)
    ↓
Canvas updates display
```

### Undo/Redo

```
User adjusts image
    ↓
Command created with before/after state
    ↓
UndoRedoManager.execute_command(command)
    ↓
Command.execute() updates image
    ↓
User presses Ctrl+Z
    ↓
UndoRedoManager.undo()
    ↓
Command.undo() restores previous state
    ↓
Canvas updates display
```

### Exporting

```
User clicks "Export As"
    ↓
FileDialog.getSaveFileName()
    ↓
MainWindow.export_image(path)
    ↓
ImageSaver.save(working_image, path, quality)
    ↓
Image converted to uint8
    ↓
Saved via PIL/Pillow with format-specific options
    ↓
User receives confirmation
```

---

## Design Patterns

### 1. Command Pattern (Undo/Redo)
```python
class EditCommand:
    def execute(self): pass
    def undo(self): pass
    def redo(self): pass
```

Allows reversible operations to be queued and replayed.

### 2. Factory Pattern (ImageLoader)
```python
ImageLoader.load(path)  # Automatically detects format
```

Creates appropriate loader based on file type.

### 3. Observer Pattern (Signals/Slots)
```python
canvas.zoom_changed.connect(on_zoom_changed)
adjustment_slider.valueChanged.connect(on_value_changed)
```

Qt's signal/slot mechanism for loose coupling.

### 4. Singleton Pattern (Application)
```python
app = QApplication(sys.argv)  # Single app instance
```

Qt enforces single application instance.

---

## Non-Destructive Editing

The architecture ensures non-destructive editing:

1. **Original Image**: Never modified, stored as-is
2. **Adjustment Parameters**: All changes stored as parameters
3. **Working Image**: Computed from original + parameters
4. **Undo/Redo**: Simply recompute from stored state

**Advantages**:
- Always reversible
- Low memory usage (no per-undo image copies)
- Can replay adjustments in different order
- Can export at any step

---

## Extensibility Points

### Adding New Adjustments

1. Add function to `app/processing/adjustments.py`:
```python
def my_new_adjustment(image, param):
    # Process image
    return adjusted_image
```

2. Add UI control in `main_window.py`:
```python
slider = ControlPanel.add_slider_control("My Adjustment", ...)
slider.valueChanged.connect(self._on_my_adjustment)
```

3. Handle signal:
```python
def _on_my_adjustment(self, value):
    self._apply_adjustment("My Adjustment", 
                          lambda img: my_new_adjustment(img, value),
                          {"my_param": value})
```

4. Add test in `tests/test_adjustments.py`

### Adding New File Format

1. Register in `app/image/formats.py`
2. Add loader in `app/image/loader.py`
3. Add saver in `app/image/saver.py` (if applicable)

### Future: AI Integration

The architecture allows local AI as a separate module:

```python
# Future: app/ai/
├── model_loader.py      # Load ML models
├── segmentation.py      # Face/skin segmentation
├── enhancement.py       # Intelligent enhancement
└── inpaint.py          # Content-aware healing
```

AI would be optional and could be toggled independently.

---

## Performance Considerations

### Memory
- Images stored in float32 (4 bytes/pixel)
- 8MP image ≈ 100MB in memory
- Undo history limited to 50 entries
- No unnecessary copies

### Processing
- NumPy vectorization (SIMD operations)
- Efficient color space conversions (OpenCV)
- Lazy evaluation where possible
- Preview resolution processing (future)

### UI
- Canvas only redraws on change
- Slider updates debounced (future)
- Async processing for expensive ops (future)

---

## Testing Strategy

### Unit Tests
- Test processing functions in isolation
- Test undo/redo logic
- Test image I/O

### Integration Tests
- Test complete workflows
- Test undo/redo with real operations

### UI Tests
- Manual testing for now
- Could use pytest-qt (future)

---

## Future Enhancements

### Phase 2+
- [ ] Layer system with masks
- [ ] Advanced curves
- [ ] HSL adjustments
- [ ] Retouching tools
- [ ] Frequency separation
- [ ] Portrait enhancement presets

### Infrastructure
- [ ] Plugin system
- [ ] Custom algorithm registration
- [ ] Local AI/ML integration
- [ ] GPU acceleration (optional)
- [ ] Project file format

---

## Dependencies

### Production
- **PySide6**: Qt GUI framework
- **NumPy**: Numerical computing
- **Pillow**: Image I/O
- **OpenCV**: Computer vision
- **scikit-image**: Advanced image processing
- **rawpy**: RAW file support (optional)

### Development
- **pytest**: Testing framework
- **PyInstaller**: Executable creation

---

## Code Quality Guidelines

1. **Type Hints**: Use for all function signatures
2. **Documentation**: Docstrings for all classes/functions
3. **Testing**: Minimum 70% coverage
4. **Style**: PEP 8 compliance
5. **Performance**: Profile before optimizing
6. **Security**: No arbitrary code execution

---

## Conclusion

ALIS DEJA VU's architecture prioritizes:

1. **Clarity** - Easy to understand and modify
2. **Testability** - Algorithms work independently
3. **Extensibility** - Add features without touching existing code
4. **Performance** - Efficient processing with NumPy
5. **Maintainability** - Clear separation of concerns

This design allows the project to grow from Phase 1 to a professional-grade application while maintaining code quality and stability.
