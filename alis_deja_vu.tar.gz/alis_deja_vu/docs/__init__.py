"""
Documentation - Project documentation and guides

Contents:
- ARCHITECTURE.md - System design and module overview
- LICENSES.md - Third-party license information
- FEATURE_RESEARCH.md - Research into photo editing techniques
"""
